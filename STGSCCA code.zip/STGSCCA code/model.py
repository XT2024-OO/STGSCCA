import torch
import torch.nn as nn
import torch.nn.functional as F
from torch_geometric.nn import GCNConv
from config import Config


class GCN_Encoder(nn.Module):
    """Spatial Graph Convolutional Encoder with node-level projection and MLP contrastive head."""

    def __init__(self, input_dim, hidden_dim, output_dim):
        super(GCN_Encoder, self).__init__()
        self.roi_count = Config.ROI_COUNT

        self.conv1 = GCNConv(input_dim, hidden_dim)
        self.conv2 = GCNConv(hidden_dim, hidden_dim)

        # Node-level linear projection back to scalar anatomical representation per ROI
        self.node_proj = nn.Linear(hidden_dim, 1)

        # Non-linear MLP projection head g(.) for InfoNCE contrastive learning
        self.projection = nn.Sequential(
            nn.Linear(self.roi_count, hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, output_dim)
        )

    def forward(self, x, edge_index):
        h = self.conv1(x, edge_index)
        h = F.relu(h)
        h = F.dropout(h, p=0.5, training=self.training)

        h = self.conv2(h, edge_index)
        h = F.relu(h)

        # Node-level denoised feature vector [Batch * ROI_COUNT, 1]
        x_rec = self.node_proj(h)

        # Reshape to subject-level anatomical vector [Batch, ROI_COUNT]
        roi_features = x_rec.view(-1, self.roi_count)

        # Latent contrastive projection
        proj = self.projection(roi_features)

        return roi_features, proj, x_rec


class TemporalAttention(nn.Module):
    """Dynamic Temporal Self-Attention pooling across longitudinal follow-up timepoints."""

    def __init__(self, feature_dim):
        super(TemporalAttention, self).__init__()
        self.attention = nn.Sequential(
            nn.Linear(feature_dim, feature_dim // 2),
            nn.Tanh(),
            nn.Linear(feature_dim // 2, 1)
        )

    def forward(self, x_seq):
        # x_seq shape: [batch_size, T=4, ROI_COUNT]
        attn_scores = self.attention(x_seq)              # [batch_size, 4, 1]
        attn_weights = F.softmax(attn_scores, dim=1)     # [batch_size, 4, 1]
        fused_features = torch.sum(x_seq * attn_weights, dim=1)  # [batch_size, ROI_COUNT]
        return fused_features, attn_weights


class Spatiotemporal_Fusion(nn.Module):
    """Full ST-GCL Architecture combining Spatial GCN Denoising and Temporal Attention Fusion."""

    def __init__(self, input_dim, hidden_dim, output_dim):
        super(Spatiotemporal_Fusion, self).__init__()
        self.spatial_gcn = GCN_Encoder(input_dim, hidden_dim, output_dim)
        self.temporal_attn = TemporalAttention(feature_dim=Config.ROI_COUNT)

    def forward(self, batch_list):
        roi_features_seq = []
        x_rec_seq = []

        # 1. Spatial graph denoising across T=4 follow-up timepoints
        for t in range(4):
            data_t = batch_list[t]
            roi_feat, _, x_rec = self.spatial_gcn(data_t.x, data_t.edge_index)
            roi_features_seq.append(roi_feat.unsqueeze(1))
            x_rec_seq.append(x_rec)

        stacked_roi_features = torch.cat(roi_features_seq, dim=1)  # [batch_size, 4, ROI_COUNT]

        # 2. Temporal self-attention pooling into a unified subject-level representation
        fused_mri, attn_weights = self.temporal_attn(stacked_roi_features)

        # 3. Map fused representation to contrastive latent space via MLP projection head
        fused_proj = self.spatial_gcn.projection(fused_mri)

        return fused_mri, fused_proj, x_rec_seq, attn_weights