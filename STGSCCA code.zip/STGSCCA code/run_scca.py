import os
import warnings
import numpy as np
import pandas as pd
from sklearn.model_selection import KFold
from sklearn.preprocessing import StandardScaler
from config import Config

warnings.filterwarnings('ignore')


class DualGraph_MTSCCA:
    """
    Back-End Dual-Graph Regularized Multi-Task Sparse Canonical Correlation Analysis (DG-MTSCCA).
    Jointly associates SNP and DNA methylation profiles with purified spatiotemporal MRI trajectories.
    """

    def __init__(self, l1_ratio=0.5, l21_ratio=0.5, l2_reg=0.5, lap_ratio=0.05, max_iter=50, tol=1e-4):
        self.l1_ratio = l1_ratio    # Element-wise L1 sparsity penalty for genetic/epigenetic loci
        self.l21_ratio = l21_ratio  # Group L2,1 sparsity penalty across neuroimaging tasks
        self.l2_reg = l2_reg        # Quadratic relaxation parameter (\beta_u, \beta_v)
        self.lap_ratio = lap_ratio  # Dual-graph Laplacian regularization coefficient (\gamma)
        self.max_iter = max_iter
        self.tol = tol

    @staticmethod
    def _build_normalized_laplacian(X):
        """Construct symmetric normalized graph Laplacian matrix L_c = I - D^{-1/2} W D^{-1/2}."""
        corr = np.nan_to_num(np.corrcoef(X.T))
        W = np.where(np.abs(corr) > 0.3, np.abs(corr), 0.0)
        np.fill_diagonal(W, 0.0)

        d_vec = np.sum(W, axis=1)
        d_inv_sqrt = np.power(d_vec + 1e-8, -0.5)
        d_inv_sqrt[np.isinf(d_inv_sqrt)] = 0.0
        D_inv_sqrt = np.diag(d_inv_sqrt)

        return np.eye(W.shape[0]) - (D_inv_sqrt @ W @ D_inv_sqrt)

    @staticmethod
    def _soft_threshold(vec, penalty_percent):
        if penalty_percent <= 0.0:
            return vec
        if penalty_percent >= 1.0:
            return np.zeros_like(vec)
        thresh = np.percentile(np.abs(vec), penalty_percent * 100)
        return np.sign(vec) * np.maximum(np.abs(vec) - thresh, 0.0)

    @staticmethod
    def _l21_soft_threshold(V_matrix, penalty_percent):
        if penalty_percent <= 0.0:
            return V_matrix
        if penalty_percent >= 1.0:
            return np.zeros_like(V_matrix)
        row_norms = np.linalg.norm(V_matrix, axis=1)
        thresh = np.percentile(row_norms, penalty_percent * 100)
        scaling = np.maximum(0.0, 1.0 - thresh / (row_norms + 1e-10))
        return V_matrix * scaling[:, np.newaxis]

    def fit(self, X1, X2, Z):
        p1, p2, q = X1.shape[1], X2.shape[1], Z.shape[1]

        L1 = self._build_normalized_laplacian(X1) if self.lap_ratio > 0 else np.zeros((p1, p1))
        L2 = self._build_normalized_laplacian(X2) if self.lap_ratio > 0 else np.zeros((p2, p2))

        self.V = np.zeros((q, 2))

        # Initialize canonical weights via Singular Value Decomposition (SVD)
        U1, _, Vt1 = np.linalg.svd(np.nan_to_num(X1.T @ Z), full_matrices=False)
        self.u1 = U1[:, 0:1]
        self.V[:, 0:1] = Vt1.T[:, 0:1]

        U2, _, Vt2 = np.linalg.svd(np.nan_to_num(X2.T @ Z), full_matrices=False)
        self.u2 = U2[:, 0:1]
        self.V[:, 1:2] = Vt2.T[:, 0:1]

        # Alternating iterative optimization
        for _ in range(self.max_iter):
            u1_old, u2_old, V_old = self.u1.copy(), self.u2.copy(), self.V.copy()

            # Update u1 (SNP canonical weight vector)
            u1_grad = X1.T @ Z @ self.V[:, 0:1] - self.lap_ratio * (L1 @ u1_old)
            u1_new = self._soft_threshold(u1_grad, self.l1_ratio) / (1.0 + self.l2_reg)
            if np.linalg.norm(u1_new) > 0:
                u1_new /= np.linalg.norm(u1_new)
            self.u1 = u1_new

            # Update u2 (DNA methylation canonical weight vector)
            u2_grad = X2.T @ Z @ self.V[:, 1:2] - self.lap_ratio * (L2 @ u2_old)
            u2_new = self._soft_threshold(u2_grad, self.l1_ratio) / (1.0 + self.l2_reg)
            if np.linalg.norm(u2_new) > 0:
                u2_new /= np.linalg.norm(u2_new)
            self.u2 = u2_new

            # Update V (Joint neuroimaging canonical weight matrix)
            V_raw = np.zeros((q, 2))
            V_raw[:, 0:1] = Z.T @ X1 @ self.u1
            V_raw[:, 1:2] = Z.T @ X2 @ self.u2

            V_new = self._l21_soft_threshold(V_raw, self.l21_ratio) / (1.0 + self.l2_reg)
            for c in range(2):
                norm_v = np.linalg.norm(V_new[:, c:c + 1])
                if norm_v > 0:
                    V_new[:, c:c + 1] /= norm_v
            self.V = V_new

            diff = max(
                np.max(np.abs(self.u1 - u1_old)),
                np.max(np.abs(self.u2 - u2_old)),
                np.max(np.abs(self.V - V_old))
            )
            if diff < self.tol:
                break

    def evaluate_ccc(self, X1, X2, Z):
        s_x1 = (X1 @ self.u1).flatten()
        s_z1 = (Z @ self.V[:, 0:1]).flatten()
        ccc_snp = np.abs(np.corrcoef(s_x1, s_z1)[0, 1]) if np.std(s_x1) > 1e-5 and np.std(s_z1) > 1e-5 else 0.0

        s_x2 = (X2 @ self.u2).flatten()
        s_z2 = (Z @ self.V[:, 1:2]).flatten()
        ccc_meth = np.abs(np.corrcoef(s_x2, s_z2)[0, 1]) if np.std(s_x2) > 1e-5 and np.std(s_z2) > 1e-5 else 0.0

        return ccc_snp, ccc_meth

    def get_weights(self):
        return self.u1.flatten(), self.u2.flatten(), self.V


def run_dg_mtscca_pipeline(snp_file, methy_file, mri_file):
    print("--- [Stage 2] Loading multi-omics and purified spatiotemporal MRI representations ---")
    if not os.path.exists(mri_file):
        raise FileNotFoundError(
            f"Cannot find {mri_file}. Please run 'python train.py' first to generate the fused MRI representation."
        )

    df_snp = pd.read_csv(snp_file, header=0, index_col=0)
    df_methy = pd.read_csv(methy_file, header=0, index_col=0)
    df_mri = pd.read_csv(mri_file, header=0, index_col=0)

    # Strictly align SubjectIDs across SNP, DNAm, and fused MRI
    common_ids = sorted(list(set(df_snp.index) & set(df_methy.index) & set(df_mri.index)))
    df_snp = df_snp.loc[common_ids]
    df_methy = df_methy.loc[common_ids]
    df_mri = df_mri.loc[common_ids]

    snp_names = np.array(df_snp.columns.tolist())
    methy_names = np.array(df_methy.columns.tolist())
    mri_names = np.array(df_mri.columns.tolist())

    X_snp_raw = np.nan_to_num(df_snp.values).astype(np.float32)
    X_methy_raw = np.nan_to_num(df_methy.values).astype(np.float32)
    Z_mri_raw = np.nan_to_num(df_mri.values).astype(np.float32)

    print(f"Aligned Cohort: N = {len(common_ids)} | SNP = {X_snp_raw.shape[1]}, DNAm = {X_methy_raw.shape[1]}, MRI = {Z_mri_raw.shape[1]}")

    l1_grid = [0.1, 0.4, 0.8]
    l21_grid = [0.1, 0.3, 0.6]

    kf = KFold(n_splits=5, shuffle=True, random_state=42)
    test_ccc_snp, test_ccc_meth = [], []
    best_l1_history, best_l21_history = [], []

    print("\n--- Executing Nested 5-Fold Cross-Validation ---")
    for fold, (train_idx, test_idx) in enumerate(kf.split(X_snp_raw), start=1):
        X_snp_tr, X_snp_te = X_snp_raw[train_idx], X_snp_raw[test_idx]
        X_methy_tr, X_methy_te = X_methy_raw[train_idx], X_methy_raw[test_idx]
        Z_mri_tr, Z_mri_te = Z_mri_raw[train_idx], Z_mri_raw[test_idx]

        # Standardize within the outer training fold only
        sc_snp = StandardScaler().fit(X_snp_tr)
        X_snp_tr, X_snp_te = sc_snp.transform(X_snp_tr), sc_snp.transform(X_snp_te)

        sc_methy = StandardScaler().fit(X_methy_tr)
        X_methy_tr, X_methy_te = sc_methy.transform(X_methy_tr), sc_methy.transform(X_methy_te)

        sc_mri = StandardScaler().fit(Z_mri_tr)
        Z_mri_tr, Z_mri_te = sc_mri.transform(Z_mri_tr), sc_mri.transform(Z_mri_te)

        # Inner validation split for hyperparameter tuning
        best_val_ccc = -1.0
        best_l1, best_l21 = 0.4, 0.3
        val_size = max(2, int(0.2 * len(X_snp_tr)))

        X_snp_in_tr, X_snp_in_val = X_snp_tr[:-val_size], X_snp_tr[-val_size:]
        X_methy_in_tr, X_methy_in_val = X_methy_tr[:-val_size], X_methy_tr[-val_size:]
        Z_mri_in_tr, Z_mri_in_val = Z_mri_tr[:-val_size], Z_mri_tr[-val_size:]

        for l1 in l1_grid:
            for l21 in l21_grid:
                inner_model = DualGraph_MTSCCA(l1_ratio=l1, l21_ratio=l21, l2_reg=0.5, lap_ratio=0.05, max_iter=20)
                inner_model.fit(X_snp_in_tr, X_methy_in_tr, Z_mri_in_tr)
                c1_val, c2_val = inner_model.evaluate_ccc(X_snp_in_val, X_methy_in_val, Z_mri_in_val)
                mean_val_ccc = 0.5 * (c1_val + c2_val)
                if mean_val_ccc > best_val_ccc:
                    best_val_ccc = mean_val_ccc
                    best_l1, best_l21 = l1, l21

        best_l1_history.append(best_l1)
        best_l21_history.append(best_l21)

        # Refit on the full outer training fold and evaluate on the held-out outer test fold
        outer_model = DualGraph_MTSCCA(l1_ratio=best_l1, l21_ratio=best_l21, l2_reg=0.5, lap_ratio=0.05, max_iter=50)
        outer_model.fit(X_snp_tr, X_methy_tr, Z_mri_tr)

        te_c1, te_c2 = outer_model.evaluate_ccc(X_snp_te, X_methy_te, Z_mri_te)
        test_ccc_snp.append(te_c1)
        test_ccc_meth.append(te_c2)
        print(f"  Fold {fold} | Tuned (L1={best_l1}, L2,1={best_l21}) | Test CCC -> SNP-MRI: {te_c1:.4f}, DNAm-MRI: {te_c2:.4f}")

    print("\n================ Cross-Validation Summary ================")
    print(f"Test CCC (SNP-MRI)  : {np.mean(test_ccc_snp):.4f} ± {np.std(test_ccc_snp):.4f}")
    print(f"Test CCC (DNAm-MRI) : {np.mean(test_ccc_meth):.4f} ± {np.std(test_ccc_meth):.4f}")
    print("==========================================================\n")

    # Fit on the complete cohort using tuned parameters to export consensus biomarker rankings
    final_model = DualGraph_MTSCCA(
        l1_ratio=float(np.mean(best_l1_history)),
        l21_ratio=float(np.mean(best_l21_history)),
        l2_reg=0.5,
        lap_ratio=0.05,
        max_iter=50
    )
    final_model.fit(
        StandardScaler().fit_transform(X_snp_raw),
        StandardScaler().fit_transform(X_methy_raw),
        StandardScaler().fit_transform(Z_mri_raw)
    )

    w_snp, w_methy, w_mri_mat = final_model.get_weights()

    df_snp_res = pd.DataFrame({'Biomarker': snp_names, 'Weight_Abs': np.abs(w_snp)}).sort_values('Weight_Abs', ascending=False)
    df_methy_res = pd.DataFrame({'Biomarker': methy_names, 'Weight_Abs': np.abs(w_methy)}).sort_values('Weight_Abs', ascending=False)
    df_mri_res = pd.DataFrame({'Brain_Region': mri_names, 'Joint_Weight_Abs': np.linalg.norm(w_mri_mat, axis=1)}).sort_values('Joint_Weight_Abs', ascending=False)

    df_snp_res.to_csv(os.path.join(Config.RESULT_DIR, "Results_Top_SNPs.csv"), index=False)
    df_methy_res.to_csv(os.path.join(Config.RESULT_DIR, "Results_Top_DNAm.csv"), index=False)
    df_mri_res.to_csv(os.path.join(Config.RESULT_DIR, "Results_Top_MRI.csv"), index=False)
    print(f"--- [Success] Ranked biomarker weights exported to {Config.RESULT_DIR}/ ---")


if __name__ == "__main__":
    run_dg_mtscca_pipeline(
        snp_file=os.path.join(Config.DATA_DIR, 'SNP.csv'),
        methy_file=os.path.join(Config.DATA_DIR, 'Meth.csv'),
        mri_file=os.path.join(Config.RESULT_DIR, 'MRI_Fused.csv')
    )