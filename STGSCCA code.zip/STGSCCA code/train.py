import os
import numpy as np
import pandas as pd
import torch
import torch.nn.functional as F
from torch_geometric.loader import DataLoader
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
import matplotlib.pyplot as plt

from config import Config
from utils import build_population_graph
from dataset import load_raw_data, BrainGraphDataset
from model import Spatiotemporal_Fusion


def train():
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    print(f"--- [Stage 1] Starting ST-GCL Self-Supervised Training (Device: {device}) ---")

    mri_list, _, _, ids, roi_names = load_raw_data()

    # Partition training and testing indices before fitting StandardScaler to prevent data leakage
    indices = np.arange(len(ids))
    train_idx, _ = train_test_split(indices, test_size=0.2, random_state=42)

    scaler = StandardScaler()
    train_combined_mri = np.vstack([m[train_idx] for m in mri_list])
    scaler.fit(train_combined_mri)

    mri_list_scaled = [scaler.transform(m) for m in mri_list]
    train_mri = [m[train_idx] for m in mri_list_scaled]

    # Build Morphological Similarity Network (MSN) strictly on the training set
    edge_index = build_population_graph(train_mri, Config.GRAPH_THRESHOLD).to(device)
    torch.save(edge_index, os.path.join(Config.RESULT_DIR, 'edge_index.pt'))

    dataset = BrainGraphDataset(train_mri, edge_index)
    loader = DataLoader(dataset, batch_size=Config.BATCH_SIZE, shuffle=True)

    model = Spatiotemporal_Fusion(
        input_dim=1,
        hidden_dim=Config.HIDDEN_DIM,
        output_dim=Config.OUTPUT_DIM
    ).to(device)

    optimizer = torch.optim.Adam(model.parameters(), lr=Config.LEARNING_RATE, weight_decay=1e-4)
    scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(optimizer, T_max=Config.EPOCHS)

    loss_history = []
    best_loss = float('inf')

    model.train()
    for epoch in range(Config.EPOCHS):
        total_loss = 0.0
        for batch_list in loader:
            batch_list = [b.to(device) for b in batch_list]
            optimizer.zero_grad()

            # Generate two stochastic augmented views via in-network dropout masks
            _, fused_proj_1, x_rec_seq_1, _ = model(batch_list)
            _, fused_proj_2, x_rec_seq_2, _ = model(batch_list)

            # 1. Node-level anatomical reconstruction loss across T=4 timepoints
            loss_recon = 0.0
            for t in range(4):
                loss_recon += (
                    F.mse_loss(x_rec_seq_1[t], batch_list[t].x) +
                    F.mse_loss(x_rec_seq_2[t], batch_list[t].x)
                )
            loss_recon = loss_recon / 4.0

            # 2. Longitudinal InfoNCE contrastive loss
            p_1 = F.normalize(fused_proj_1, dim=1)
            p_2 = F.normalize(fused_proj_2, dim=1)

            logits = torch.matmul(p_1, p_2.T) / Config.TEMPERATURE
            labels = torch.arange(p_1.shape[0], device=device)
            loss_nce = F.cross_entropy(logits, labels)

            # 3. Joint optimization objective
            loss = loss_nce + Config.RECON_WEIGHT * loss_recon
            loss.backward()
            optimizer.step()
            total_loss += loss.item()

        scheduler.step()
        avg_loss = total_loss / len(loader)
        loss_history.append(avg_loss)

        if avg_loss < best_loss:
            best_loss = avg_loss
            torch.save(model.state_dict(), os.path.join(Config.RESULT_DIR, 'fusion_model.pth'))

        if (epoch + 1) % 20 == 0 or epoch == 0:
            print(f"Epoch [{epoch + 1:03d}/{Config.EPOCHS:03d}] | Joint Loss: {avg_loss:.4f}")

    # Plot training convergence curve
    plt.figure(figsize=(8, 4.5))
    plt.plot(loss_history, label='Joint Loss (InfoNCE + Reconstruction)', color='teal', linewidth=2)
    plt.title('ST-GCL Self-Supervised Convergence')
    plt.xlabel('Epoch')
    plt.ylabel('Loss')
    plt.legend()
    plt.tight_layout()
    plt.savefig(os.path.join(Config.RESULT_DIR, 'train_loss.png'), dpi=300)
    plt.close()

    # Discard MLP projection head and export purified subject-level spatiotemporal representation Z
    print("\n--- [Export] Extracting purified spatiotemporal neuroimaging matrix ---")
    model.load_state_dict(torch.load(os.path.join(Config.RESULT_DIR, 'fusion_model.pth'), weights_only=True))
    model.eval()

    full_dataset = BrainGraphDataset(mri_list_scaled, edge_index)
    full_loader = DataLoader(full_dataset, batch_size=Config.BATCH_SIZE, shuffle=False)

    extracted_features = []
    with torch.no_grad():
        for batch_list in full_loader:
            batch_list = [b.to(device) for b in batch_list]
            fused_mri, _, _, _ = model(batch_list)
            extracted_features.append(fused_mri.cpu().numpy())

    Z_mri_full = np.vstack(extracted_features)
    cols = roi_names if len(roi_names) == Z_mri_full.shape[1] else [f'ROI_{i + 1}' for i in range(Z_mri_full.shape[1])]

    df_export = pd.DataFrame(Z_mri_full, columns=cols)
    df_export.insert(0, 'SubjectID', ids)

    export_path = os.path.join(Config.RESULT_DIR, 'MRI_Fused.csv')
    df_export.to_csv(export_path, index=False)
    print(f"--- [Export] Saved purified spatiotemporal representation to: {export_path} ---")


if __name__ == "__main__":
    train()