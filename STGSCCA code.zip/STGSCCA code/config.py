import os


class Config:
    # ================== Directory Settings ==================
    DATA_DIR = './data'
    RESULT_DIR = './results'

    # ================== Data Dimensions ==================
    # Number of brain regions of interest (AAL-90 atlas)
    ROI_COUNT = 90

    # ================== Model Hyperparameters ==================
    HIDDEN_DIM = 64        # GCN hidden layer dimension
    OUTPUT_DIM = 32        # Contrastive projection head output dimension
    TEMPERATURE = 0.1      # InfoNCE temperature scaling parameter
    RECON_WEIGHT = 0.1     # Reconstruction loss balancing weight (\beta)

    # ================== Training Parameters ==================
    EPOCHS = 200           # Number of self-supervised training epochs
    BATCH_SIZE = 32        # Batch size
    LEARNING_RATE = 0.001  # Initial learning rate for Adam optimizer

    # ================== Graph Construction ==================
    # Pearson correlation threshold (\theta) for Morphological Similarity Network
    GRAPH_THRESHOLD = 0.4

    @staticmethod
    def init_dirs():
        os.makedirs(Config.DATA_DIR, exist_ok=True)
        os.makedirs(Config.RESULT_DIR, exist_ok=True)


Config.init_dirs()