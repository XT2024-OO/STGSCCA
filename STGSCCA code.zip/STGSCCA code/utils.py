import numpy as np
import torch
from config import Config


def build_population_graph(mri_data_list, threshold):
    """
    Construct the Morphological Similarity Network (MSN) across brain ROIs
    using training set observations to prevent cross-sample data leakage.
    """
    print(f"--- [Utils] Constructing ROI Morphological Similarity Network (threshold = {threshold}) ---")

    # Stack training observations across timepoints to compute inter-regional Pearson correlation
    combined = np.vstack(mri_data_list)
    corr_matrix = np.corrcoef(combined.T)
    corr_matrix = np.nan_to_num(corr_matrix)

    # Binarize adjacency matrix based on threshold and remove self-loops
    adj = np.abs(corr_matrix) >= threshold
    np.fill_diagonal(adj, 0)

    rows, cols = np.where(adj)
    edge_index = torch.tensor(np.array([rows, cols]), dtype=torch.long)

    print(f"--- [Utils] Graph constructed: {Config.ROI_COUNT} nodes, {edge_index.shape[1]} edges ---")
    if edge_index.shape[1] == 0:
        print("[Warning] No edges retained. Consider lowering GRAPH_THRESHOLD in config.py.")

    return edge_index