import os
import pandas as pd
import numpy as np
import torch
from torch_geometric.data import Data, Dataset
from config import Config


class BrainGraphDataset(Dataset):
    """PyTorch Geometric Dataset wrapper for 4-timepoint longitudinal brain graphs."""

    def __init__(self, mri_matrices, edge_index):
        super().__init__()
        self.mri_list = mri_matrices
        self.edge_index = edge_index
        self.n_samples = mri_matrices[0].shape[0]

    def __len__(self):
        return self.n_samples

    def __getitem__(self, idx):
        graphs = []
        for t in range(4):
            x_val = self.mri_list[t][idx]
            x = torch.tensor(x_val, dtype=torch.float).view(-1, 1)
            data = Data(x=x, edge_index=self.edge_index)
            graphs.append(data)
        return graphs


def load_raw_data():
    """Load and align longitudinal sMRI (T1-T4), SNP, and DNA methylation CSV files."""
    print("--- [Data] Loading multi-modal longitudinal neuroimaging and omics datasets ---")

    try:
        # 1. Load 4 longitudinal MRI files (T1 to T4)
        dfs_mri = []
        for t in range(1, 5):
            path = os.path.join(Config.DATA_DIR, f'MRI_T{t}.csv')
            df = pd.read_csv(path)
            df.rename(columns={df.columns[0]: 'SubjectID'}, inplace=True)
            dfs_mri.append(df)

        # Preserve anatomical ROI column names from baseline MRI_T1.csv
        roi_names = dfs_mri[0].columns[1:].tolist()

        # 2. Load baseline SNP file
        snp_path = os.path.join(Config.DATA_DIR, 'SNP.csv')
        df_snp = pd.read_csv(snp_path)
        df_snp.rename(columns={df_snp.columns[0]: 'SubjectID'}, inplace=True)

        # 3. Load baseline DNA methylation file
        meth_path = os.path.join(Config.DATA_DIR, 'Meth.csv')
        df_meth = pd.read_csv(meth_path)
        df_meth.rename(columns={df_meth.columns[0]: 'SubjectID'}, inplace=True)

    except FileNotFoundError as e:
        raise FileNotFoundError(
            f"Data file missing: {e}. Please place MRI_T1~T4.csv, SNP.csv, and Meth.csv in {Config.DATA_DIR}/"
        )

    # 4. Align subjects across all modalities by taking the intersection of SubjectIDs
    common_ids = set(dfs_mri[0]['SubjectID'])
    for df in dfs_mri[1:]:
        common_ids = common_ids.intersection(set(df['SubjectID']))
    common_ids = common_ids.intersection(set(df_snp['SubjectID']))
    common_ids = common_ids.intersection(set(df_meth['SubjectID']))

    sorted_ids = sorted(list(common_ids))
    if len(sorted_ids) == 0:
        raise ValueError("No overlapping SubjectIDs found across the input CSV files.")

    print(f"--- [Data] Successfully aligned {len(sorted_ids)} matched subjects across all modalities ---")

    # 5. Extract aligned numerical feature matrices
    mri_matrices = []
    for df in dfs_mri:
        mat = df[df['SubjectID'].isin(sorted_ids)].sort_values('SubjectID').iloc[:, 1:].values
        mri_matrices.append(np.nan_to_num(mat).astype(np.float32))

    snp_matrix = df_snp[df_snp['SubjectID'].isin(sorted_ids)].sort_values('SubjectID').iloc[:, 1:].values
    meth_matrix = df_meth[df_meth['SubjectID'].isin(sorted_ids)].sort_values('SubjectID').iloc[:, 1:].values

    return (
        mri_matrices,
        np.nan_to_num(snp_matrix).astype(np.float32),
        np.nan_to_num(meth_matrix).astype(np.float32),
        sorted_ids,
        roi_names
    )